from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        # Edited to update connection variables.
        # Connection Variables
        #
        user = 'aacuser'
        password = 'SNHU1234'
        host = 'nv-desktop-services.apporto.com'
        port = 32807
        db = 'AAC'
        collection = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

# Completed this to create method to implement the C in CRUD.
    def create(self, data):
        """
        Inserts document into specified collection
        :param data: (dict) key/value pair for the document
        :return: bool: True if successful insertion, False if not 423.

        """
        if data is None or not isinstance(data, dict):
            raise ValueError("Data must be a dictionary and not empty.")
        try:
            result = self.database.animals.insert_one(data)  # data should be dictionary
            return result.acknowledged
        except Exception as e:
            print(f"Error: {str(e)}")
            return False

# Created method to implement the read method.
    def read(self, query):
        """
        Queries for documents from specified collection
        :param query: (dict) key/value pair to find documents
        :return: pymongo.cursor.Cursor if successful
        """
        try:
            result = self.database.animals.find(query)
            return result
        except Exception as e:
            print(f"Error: {str(e)}")
            return None

# Created method to update documents
    def update(self, query, new_data, update_many=False):
        """
        Finds and updates documents from specified collection
        :param query: (dict) key/value pair to find the documents
        :param new_data: (dict) key/value pair to update
        :param update_many: (bool) if True use update_many() method otherwise use update_one
        :return: int: the number of objects modified
        """
        if query is None or not isinstance(query, dict):
            raise ValueError("Query must be a dictionary and not empty")
        if new_data is None or not isinstance(new_data, dict):
            raise ValueError("new_data must be a dictionary and not empty")
        if update_many:
            try:
                result = self.database.animals.update_many(query, new_data)
                return result.modified_count
            except Exception as e:
                print(f"Error: {str(e)}")
        else:
            try:
                result = self.database.animals.update_one(query, new_data)
                return result.modified_count
            except Exception as e:
                print(f"Error: {str(e)}")

# Created method to delete documents
    def delete(self, data):
        """
        Deletes documents from specified collection
        :param data: (dict) key/value pair to data to delete
        :return: int: number of objects deleted
        """
        if data is None:
            raise ValueError("Data must be a dictionary and not empty.")
        try:
            result = self.database.animals.delete_one(data)
            return result.deleted_count
        except Exception as e:
            print(f"Error: {str(e)}")
