package com.example.rubybinghamapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Database2Helper extends SQLiteOpenHelper {
    public static final String database2Name = "Items.db";
    public static final String tableName = "Items";
    public static final String NAME = "name";
    public static final String DESC = "description";
    public static final String QUANTITY = "quantity";

    public Database2Helper(@Nullable Context context) {
        super(context, database2Name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDatabase) {
        MyDatabase.execSQL("create Table items(name TEXT primary key, description TEXT, quantity TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDatabase, int i, int i1) {
        MyDatabase.execSQL("drop Table if exists items");
    }

    public Boolean createItem(String name, String description, String quantity) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME, name);
        contentValues.put(DESC, description);
        contentValues.put(QUANTITY, quantity);
        long result = MyDatabase.insert(tableName, null, contentValues);

        return result != -1;
    }

    public Boolean updateItemQuantity(String name, String quantity) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(QUANTITY, quantity);
        long result = MyDatabase.update(tableName, contentValues, "name = ?", new String[]{name});
        return result != -1;
    }

    public Boolean deleteItem(String name) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        long result = MyDatabase.delete(tableName, "name = ?", new String[]{name});
        return result != -1;
    }

    public Cursor findItem() {
        SQLiteDatabase MyDatabase = this.getReadableDatabase();
        Cursor cursor = MyDatabase.rawQuery("select * from Items", null);

        return cursor;
    }
}
