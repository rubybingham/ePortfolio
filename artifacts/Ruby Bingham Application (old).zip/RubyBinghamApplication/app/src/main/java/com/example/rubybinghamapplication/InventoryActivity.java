package com.example.rubybinghamapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.rubybinghamapplication.databinding.ActivityInventoryBinding;
import com.example.rubybinghamapplication.databinding.ActivityLogInBinding;

import java.util.ArrayList;


public class InventoryActivity extends AppCompatActivity {

    Database2Helper database2Helper;
    ActivityInventoryBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInventoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.addItemButton.setOnClickListener( v -> {
            Intent intent = new Intent(getApplicationContext(), AddItem.class);
            startActivity(intent);}
        );
        /* FIXME!!!
        setContentView(R.layout.activity_inventory);
        database2Helper = new Database2Helper(this);
        ListView lvItems = findViewById(R.id.lvItems);

        ArrayList<String> inventoryList = new ArrayList<>();
        Cursor data = database2Helper.findItem();

        while (data.moveToNext()) {
            inventoryList.add(data.getString(0));
            ListAdapter listAdapter = new ArrayAdapter<>(this, R.layout.list_row_view, inventoryList);
            lvItems.setAdapter(listAdapter);
        }*/
    }
}