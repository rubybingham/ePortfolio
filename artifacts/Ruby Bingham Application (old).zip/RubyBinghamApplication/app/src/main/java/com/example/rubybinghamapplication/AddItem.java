package com.example.rubybinghamapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.rubybinghamapplication.databinding.ActivityAddItemBinding;

public class AddItem extends AppCompatActivity {

    ActivityAddItemBinding binding;
    Database2Helper database2Helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddItemBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database2Helper = new Database2Helper(this);
        binding.addItemButton.setOnClickListener(v -> {
            String name = binding.editName.getText().toString();
            String desc = binding.editDescription.getText().toString();
            String quantity = binding.editQuantity.getText().toString();

            if (name.isEmpty() || desc.isEmpty() || quantity.isEmpty())
                Toast.makeText(AddItem.this, "You must fill all fields", Toast.LENGTH_SHORT).show();
            else {
                Boolean insert = database2Helper.createItem(name, desc, quantity);
                if (insert == true) {
                    Toast.makeText(AddItem.this, "Item added", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddItem.this, "Item was not added", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}