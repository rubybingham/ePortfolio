package com.example.rubybinghamapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.rubybinghamapplication.databinding.ActivitySignUpBinding;

public class SignUp extends AppCompatActivity {

    ActivitySignUpBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper(this);

        binding.signupButton.setOnClickListener(v -> {
            String email = binding.signupEmail.getText().toString();
            String password = binding.signupPassword.getText().toString();
            String confirmPassword = binding.signupConfirm.getText().toString();

            if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty())
                Toast.makeText(SignUp.this, "You must fill all fields.", Toast.LENGTH_SHORT).show();
            else {
                if (password.equals(confirmPassword)){
                    Boolean checkUserEmail = databaseHelper.checkEmail(email);

                    if (checkUserEmail == false){
                        Boolean insert = databaseHelper.insertData(email, password);

                        if (insert == true){
                            Toast.makeText(SignUp.this, "Signup Succeeded", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), LogIn.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(SignUp.this, "Signup Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(SignUp.this, "User already exists, Login instead.", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(SignUp.this, "Invalid Password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.loginRedirectText.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), LogIn.class);
            startActivity(intent);
        });

    }
}