package com.example.rubybinghamapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.rubybinghamapplication.databinding.ActivityUpdateQuantityBinding;

public class UpdateQuantity extends AppCompatActivity {

    ActivityUpdateQuantityBinding binding;
    Database2Helper database2Helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateQuantityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database2Helper = new Database2Helper(this);
        binding.updateQuantity.setOnClickListener(v -> {
            String name = binding.itemName.getText().toString();
            String quantity = binding.editQuantity.getText().toString();
            if (quantity.isEmpty())
                Toast.makeText(UpdateQuantity.this, "You must enter new quantity", Toast.LENGTH_SHORT).show();
            else {
                Boolean insert = database2Helper.updateItemQuantity(name, quantity);
                if (insert == true) {
                    Toast.makeText(UpdateQuantity.this, "Item quantity updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(UpdateQuantity.this, "Item was not updated", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}