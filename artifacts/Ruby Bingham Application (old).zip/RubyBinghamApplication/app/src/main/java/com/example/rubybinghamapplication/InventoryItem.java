package com.example.rubybinghamapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.rubybinghamapplication.databinding.ActivityInventoryItemBinding;

public class InventoryItem extends AppCompatActivity {
    ActivityInventoryItemBinding binding;
    Database2Helper database2Helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInventoryItemBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database2Helper = new Database2Helper(this);
        binding.changeQuantity.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryItem.this, UpdateQuantity.class);
            startActivity(intent);
        });
        binding.deleteButton.setOnClickListener(v -> {
            String name = binding.itemName.getText().toString();
            Boolean delete = database2Helper.deleteItem(name);

            if (delete == true) {
                Toast.makeText(InventoryItem.this, "Item deleted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(InventoryItem.this, InventoryActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(InventoryItem.this, "Item not deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }
}