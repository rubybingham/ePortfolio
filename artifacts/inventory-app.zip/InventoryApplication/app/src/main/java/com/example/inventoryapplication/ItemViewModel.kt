package com.example.inventoryapplication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class ItemViewModel(private val repository: ItemRepository) : ViewModel() {

    val allItems: Flow<List<Item>> = repository.allItems

    fun addItem(name: String, quantity: Int) {
        viewModelScope.launch {
            repository.insert(Item(name = name, quantity = quantity))
        }
    }

    fun clearItems() {
        viewModelScope.launch {
            repository.deleteAll()
        }
    }

    fun deleteItem(item: Item) {
        viewModelScope.launch {
            repository.delete(item)
        }
    }

    fun updateItem(item: Item) {
        viewModelScope.launch {
            repository.update(item)
        }
    }
}