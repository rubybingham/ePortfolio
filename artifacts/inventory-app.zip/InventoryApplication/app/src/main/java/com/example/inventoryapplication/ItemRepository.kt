package com.example.inventoryapplication

import kotlinx.coroutines.flow.Flow

class ItemRepository (private val itemDao: ItemDao) {

    val allItems: Flow<List<Item>> = itemDao.getAllItems()

    suspend fun insert(item: Item) {
        itemDao.insertItem(item)
    }

    suspend fun deleteAll() {
        itemDao.deleteAll()
    }

    suspend fun delete(item: Item) {
        itemDao.deleteItem(item)
    }

    suspend fun update(item: Item) {
        itemDao.updateItem(item)
    }
}