package com.example.inventoryapplication

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults

@Composable
fun InventoryScreen(
    items: List<Item>,
    onAddItem: (String, Int) -> Unit,
    onClear: () -> Unit,
    onDelete: (Item) -> Unit,
    onEdit: (Item) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var editingItem by remember { mutableStateOf<Item?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Column(Modifier.padding(16.dp)) {

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Item name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = quantity,
            onValueChange = { quantity = it },
            label = { Text("Quantity") },
            modifier = Modifier.fillMaxWidth()
        )

        Row {
            Button(
                onClick = {
                    if (name.isNotBlank() && quantity.isNotBlank()) {
                        onAddItem(name, quantity.toInt())
                        name = ""
                        quantity = ""
                    }
                },
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text("Add")
            }

            Button(onClick = onClear) {
                Text("Clear")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(items) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { println("CLICKED: ${item.name}")
                            editingItem = item },
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = item.name, style = MaterialTheme.typography.titleMedium)
                        Text(text = "Qty: ${item.quantity}")
                    }
                }
            }
        }

        editingItem?.let { item ->
            AlertDialog(
                onDismissRequest = { editingItem = null },
                confirmButton = {
                    Button(onClick = {
                        onEdit(
                            item.copy(
                                name = name,
                                quantity = quantity.toInt()
                            )
                        )
                        editingItem = null
                    }) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    Row {
                        Button(onClick = { editingItem = null }) {
                            Text("Cancel")
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { showDeleteConfirm = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("Delete")
                        }
                    }
                },
                title = { Text("Edit Item") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Item name") }
                        )
                        OutlinedTextField(
                            value = quantity,
                            onValueChange = { quantity = it },
                            label = { Text("Quantity") }
                        )
                    }
                }
            )
        }
        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Delete Item?") },
                text = { Text("Are you sure you want to delete this item? This action cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            onDelete(editingItem!!)
                            showDeleteConfirm = false
                            editingItem = null
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    Button(onClick = { showDeleteConfirm = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}