package com.example.inventoryapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue


class MainActivity : ComponentActivity() {

    private val database by lazy { AppDatabase.getDatabase(this) }
    private val repository by lazy { ItemRepository(database.itemDao()) }
    private val viewModel: ItemViewModel by viewModels {
        ItemViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val db = AppDatabase.getDatabase(this)
            val itemRepository = ItemRepository(db.itemDao())
            val itemViewModel = ItemViewModel(itemRepository)
            val userViewModel = UserViewModel(db)

            var loggedIn by remember { mutableStateOf(false) }

            if (!loggedIn) {
                LoginScreen(
                    onLoginSuccess = { loggedIn = true },
                    onRegister = { username, password ->
                        userViewModel.register(username, password) { success ->
                            if (success) loggedIn = true
                        }
                    },
                    onLogin = { username, password ->
                        userViewModel.login(username, password) { success ->
                            if (success) loggedIn = true
                        }
                    }
                )
            } else {
                InventoryScreen(
                    items = itemViewModel.allItems.collectAsState(initial = emptyList()).value,
                    onAddItem = itemViewModel::addItem,
                    onClear = itemViewModel::clearItems,
                    onDelete = itemViewModel::deleteItem,
                    onEdit = itemViewModel::updateItem
                )
            }
        }
    }
}