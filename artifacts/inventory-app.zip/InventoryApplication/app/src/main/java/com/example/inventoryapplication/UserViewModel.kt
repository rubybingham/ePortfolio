package com.example.inventoryapplication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class UserViewModel(private val db: AppDatabase) : ViewModel() {

    var loggedInUser: User? = null
        private set

    fun register(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                db.userDao().registerUser(User(username = username, password = password))
                onResult(true)
            } catch (e: Exception) {
                onResult(false)
            }
        }
    }

    fun login(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val user = db.userDao().login(username, password)
            if (user != null) {
                loggedInUser = user
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }
}